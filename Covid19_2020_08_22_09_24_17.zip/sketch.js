function setup() {
  createCanvas(400, 400);
  background(220);
  
  
  
  
  
  
  
}

function draw() {
  
  covid19(200,200)
  
function covid19(xpos,ypos){
  fill(200,0,0);
  line( 100, 200, 300, 200) 
  line( 200, 100, 200, 300) 
  line(110,110,290,290)
  line(110,290,290,110)
  fill(200,0,0)
  circle(100,100,30)
  circle(200,100,30)
  circle(100,200,30)
  circle(110,290,30)
  circle(300,300,30)
  circle(300,100,30)
 circle(200,300,30)
  circle(300,200,30)
  
   circle(xpos,ypos,150);
  fill(0,200,0);
 circle(170,170,30);
  circle(230,170,30);
  fill(0,0,200);
  translate(width / 2, height / 40);
  rotate(PI / 3.0);
  rect(90, 90, 50, 15)
  translate(width / 2, height / 40);
  rotate(PI / 3.0);
  rect(-20, 65, 50, 15)
  arc(70, 50, 70, 80, 0,QUARTER_PI+ PI, CHORD);
}
   
 
}